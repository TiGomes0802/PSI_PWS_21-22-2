var countre=0;
$(function (){
    const $addCar = $('.btn-add-to-cart');
    add_more_product
});
function add_more_product(){
    countre+=1
    html='<br>\n' +
        '<div id="product_form">\n' +
        '    <div class="row"id="row1">\n' +
        '        <div class="col-md-1">\n' +
        '            <label></label>\n' +
        '            <input type="button" value="produto" class="form-control">\n' +
        '        </div>\n' +
        '        <div class="col">\n' +
        '            <label>Produto id</label>\n' +
        '            <input type="number" name="produto_id'+countre+'" class="form-control">\n' +
        '        </div>\n' +
        '        <div class="col">\n' +
        '            <label>Valor</label>\n' +
        '            <input type="number" name="valor'+countre+'" class="form-control">\n' +
        '        </div>\n' +
        '        <div class="col">\n' +
        '            <label>Valor Iva</label>\n' +
        '            <input type="number" name="valoriva'+countre+'" class="form-control">\n' +
        '        </div>\n' +
        '        <div class="col">\n' +
        '            <label>Quantidade</label>\n' +
        '            <input type="number" name="quantidade'+countre+'" class="form-control">\n' +
        '        </div>\n' +
        '    </div>\n' +
        '</div>'
    var form=document.getElementById('product_form')
    form.innerHTML+=html

    document.getElementById("demo").value = countre
}