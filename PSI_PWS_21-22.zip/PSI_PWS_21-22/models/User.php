<?php

class User extends \ActiveRecord\Model
{
    static $validates_presence_of = array(
        array('username', 'message' => 'Campo Obrigatorio'),
        array('password', 'message' => 'Campo Obrigatorio'),
        array('email', 'message' => 'Campo Obrigatorio'),
        array('telefone', 'message' => 'Campo Obrigatorio'),
        array('nif', 'message' => 'Campo Obrigatorio'),
        array('morada', 'message' => 'Campo Obrigatorio'),
        array('codigopostal', 'message' => 'Campo Obrigatorio'),
        array('localidade', 'message' => 'Campo Obrigatorio'),
        array('role', 'message' => 'Campo Obrigatorio'),
    );

    static $has_many = array(
        array('faturas')
    );

}