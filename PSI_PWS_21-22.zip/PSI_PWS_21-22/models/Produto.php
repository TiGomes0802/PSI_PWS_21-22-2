<?php

class Produto extends \ActiveRecord\Model
{
    static $validates_presence_of = array(
        array('referencia', 'message' => 'Campo Obrigatorio'),
        array('descricao', 'message' => 'Campo Obrigatorio'),
        array('preco', 'message' => 'Campo Obrigatorio'),
        array('stock', 'message' => 'Campo Obrigatorio'),
        array('iva_id', 'message' => 'Campo Obrigatorio'),
    );

    public function validatequantidade($quantidade)
    {
        if ($this->stock >= $quantidade)
        {
            $this->errors->add('quantidade', "Quantidade invalida");
        }
    }

    static $belongs_to = array(
        array('iva')
    );

}