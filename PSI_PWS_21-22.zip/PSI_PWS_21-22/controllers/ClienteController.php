<?php

require_once 'BaseAuthController.php';

class ClienteController extends BaseAuthController
{
    public function __construct()
    {
        $this->loginFilter();
    }

    public function index()
    {
        $clientes = User::find_all_by_role("cliente");

        //mostrar a vista index passando os dados por parâmetro
        $this->renderView('cliente', 'index', ['clientes' => $clientes]);

    }

    public function show($id)
    {
        $cliente = User::find([$id]);
        if (is_null($cliente)) {
            //TODO redirect to standard error page
        } else {
            //mostrar a vista show passando os dados por parâmetro
            $this->renderView('cliente','show', ['cliente' => $cliente]);
        }

    }

    public function create()
    {
        //mostrar a vista create
        $this->renderView('cliente','create');
    }

    public function store()
    {
            //create new resource (activerecord/model) instance with data from POST
            //your form name fields must match the ones of the table fields
            $cliente = new Empresa($_POST);
            if($cliente->is_valid()){
                $cliente->save();
                //redirecionar para o index
                $this->redirectToRoute('cliente', 'index');
            } else {
                //mostrar vista edit passando o modelo como parâmetro
                $this->renderView('cliente','create', ['cliente' => $cliente]);
            }
    }

    public function edit($id)
    {
        $cliente = User::find([$id]);
        if (is_null($cliente)) {
            //TODO redirect to standard error page
        } else {
            //mostrar a vista edit passando os dados por parâmetro
            $this->renderView('cliente','edit', ['cliente' => $cliente]);
        }
    }

    public function update($id)
    {
        //find resource (activerecord/model) instance where PK = $id
        //your form name fields must match the ones of the table fields
        $cliente = User::find([$id]);
        $cliente->update_attributes($_POST);
        if($cliente->is_valid()){
            $cliente->save();
            //redirecionar para o index
            $clientes = User::all();
            $this->renderView('cliente','index', ['clientes' => $clientes]);
        } else {
            //mostrar vista edit passando o modelo como parâmetro
            $this->renderView('cliente','edit', ['cliente' => $cliente]);
        }
    }

    public function delete($id)
    {
        $cliente = User::find([$id]);
        $cliente->delete();
        //redirecionar para o index
        $clientes = User::all();
        $this->renderView('cliente','index', ['clientes' => $clientes]);
    }

}
