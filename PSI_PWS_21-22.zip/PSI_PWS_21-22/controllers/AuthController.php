<?php

require_once 'BaseAuthController.php';

class AuthController extends BaseAuthController
{

    public function index()
    {
        $this->renderView('auth','index');
    }

    public function login()
    {
         $auth = new Auth();

         $sessao = $auth->checkAuth($_POST['username'], $_POST['password']);

         if($sessao) {
             $this->redirectToRoute('fatura', 'index');
         } else{
             $this->redirectToRoute('auth', 'index');
         }
    }

    public function logout()
    {
        $auth =  new Auth();

        $auth->logout();
        $this->redirectToRoute('auth', 'index');
    }

    public function getUser(){
        //devolver o user utenticado
    }

}
