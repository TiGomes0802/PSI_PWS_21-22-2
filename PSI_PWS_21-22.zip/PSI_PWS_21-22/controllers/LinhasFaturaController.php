<?php

require_once 'BaseAuthController.php';

class LinhasFaturaController extends BaseAuthController
{

    public function __construct()
    {
        $this->loginFilter();
    }

    public function create($id_fatura)
    {
        //if ($this->loginFilter()) {
            $fatura = Fatura::find_by_id([$id_fatura]);
            if ($fatura->estado !="emitida"){
                $linhasfatura = Linhasfatura::find_all_by_fatura_id([$id_fatura]);

                //mostrar a vista create
                $this->renderView('linhasfatura','create', ['fatura' => $fatura, 'linhasfatura' => $linhasfatura]);
            }else{
                $this->redirectToRoute('fatura', 'index');
            }

        //}
    }

    public function store($id_fatura)
    {
        $produto = Produto::find_by_referencia($_POST['referencia']);
        $fatura = Fatura::find_by_id([$id_fatura]);
        $linhasfatura = new LinhasFatura();
        $faturas = new Fatura();


        $produto->stock -= $_POST['quantidade'];
        //$produto->validadetequantidade($_POST['quantidade']);

            if($produto->is_valid()){

                $produto->save();

                $linhasfatura->valor = $linhasfatura->getValor($_POST['quantidade'], $produto->id);
                $linhasfatura->valoriva = $linhasfatura->getValorIva($_POST['quantidade'], $produto->id);
                $linhasfatura->quantidade = $_POST['quantidade'];
                $linhasfatura->produto_id = $produto->id;
                $linhasfatura->fatura_id = $id_fatura;

                if($linhasfatura->is_valid()){
                    $linhasfatura->save();

                    $linhasfatura = Linhasfatura::find_all_by_fatura_id([$id_fatura]);

                    $fatura->valortotal = $faturas->getvalor($linhasfatura);
                    $fatura->ivatotal = $faturas->getvaloriva($linhasfatura);

                    if($fatura->is_valid()) {
                        $fatura->save();

                        $this->redirectToRoute('linhasfatura', 'create', ['id_fatura' => $fatura->id]);
                    }else{
                        $this->renderView('linhasfatura','create', ['fatura' => $fatura, 'linhasfatura' => $linhasfatura]);
                    }
                } else {
                    //mostrar vista edit passando o modelo como parâmetro
                    $this->renderView('linhasfatura','create', ['fatura' => $fatura, 'linhasfatura' => $linhasfatura]);
                }

            }else {

                $this->renderView('linhasfatura','create', ['fatura' => $fatura, 'linhasfatura' => $linhasfatura, 'produto' => $produto]);
            }
    }

    public function delete($id)
    {
        $linhasfatura = Linhasfatura::find([$id]);
        $fatura = Fatura::find_by_id($linhasfatura->fatura_id);
        if ($fatura->estado !="emitida"){

            $linhasfatura->delete();

            $faturas = new Fatura();
            $linhasfatura = Linhasfatura::find_all_by_fatura_id([$fatura->id]);

            $fatura->valortotal = $faturas->getvalor($linhasfatura);
            $fatura->ivatotal = $faturas->getvaloriva($linhasfatura);

            if($fatura->is_valid()) {
                $fatura->save();

                $this->redirectToRoute('linhasfatura', 'create', ['id_fatura' => $fatura->id]);
            }else{
                $this->renderView('linhasfatura','create', ['fatura' => $fatura, 'linhasfatura' => $linhasfatura]);
            }
        }else{
            $this->redirectToRoute('fatura', 'index');
        }
    }

}