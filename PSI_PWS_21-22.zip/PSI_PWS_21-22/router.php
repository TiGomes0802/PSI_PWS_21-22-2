<?php
    require_once 'startup/boot.php';
    require_once 'controllers/AuthController.php';
    require_once 'controllers/EmpresaController.php';
    require_once 'controllers/FaturaController.php';
    require_once 'controllers/ClienteController.php';
    require_once 'controllers/LinhasFaturaController.php';

    if(!(isset($_GET['c']) AND isset($_GET['a']))){
        $auth = new AuthController();
        $auth->index();
    }else{

        $controller = $_GET['c'];
        $action = $_GET['a'];

        switch ($controller){
            case 'auth':
                $auth = new AuthController();
                switch ($action){
                    case 'index':
                        $auth->index();
                        break;
                    case 'login':
                        $auth->login();
                        break;
                    case 'logout':
                        $auth->logout();
                        break;
                }
                break;
            case 'empresa':
                $empresa = new EmpresaController();
                switch ($action) {
                    case 'show':
                        $id = $_GET['id'];
                        $empresa->show($id);
                        break;
                    case 'edit':
                        $id = $_GET['id'];
                        $empresa->edit($id);
                        break;
                    case 'update':
                        $id = $_GET['id'];
                        $empresa->update($id);
                        break;
                }
                break;
            case 'fatura':
                $fatura = new FaturaController();
                switch ($action) {
                    case 'index':
                        $fatura->index();
                        break;
                    case 'create':
                        $id_cliente = $_GET['id_cliente'];
                        $fatura->create($id_cliente);
                        break;
                    case 'store':
                        $id_cliente = $_GET['id_cliente'];
                        $fatura->store($id_cliente);
                        break;
                    case 'show':
                        $id = $_GET['id'];
                        $fatura->show($id);
                        break;
                    case 'updateestado':
                        $id = $_GET['id'];
                        $fatura->updateestado($id);
                        break;
                    case 'update':
                        $id = $_GET['id'];
                        $fatura->update($id);
                        break;
                    case 'delete':
                        $id = $_GET['id'];
                        $fatura->delete($id);
                        break;
                }
                break;
            case 'cliente':
                $cliente = new ClienteController();
                switch ($action) {
                    case 'index':
                        $cliente->index();
                        break;
                    case 'create':
                        $cliente->create();
                        break;
                    case 'store':
                        $cliente->store();
                        break;
                    case 'show':
                        $id = $_GET['id'];
                        $cliente->show($id);
                        break;
                    case 'edit':
                        $id = $_GET['id'];
                        $cliente->edit($id);
                        break;
                    case 'update':
                        $id = $_GET['id'];
                        $cliente->update($id);
                        break;
                    case 'delete':
                        $id = $_GET['id'];
                        $cliente->delete($id);
                        break;
                }
                break;
                case 'linhasfatura':
                $linhasfatura = new LinhasFaturaController();
                switch ($action) {
                    //case 'index':
                    //    $linhasfatura->index();
                    //    break;
                    case 'create':
                        $id = $_GET['id_fatura'];
                        $linhasfatura->create($id);
                        break;
                    case 'store':
                        $id = $_GET['id_fatura'];
                        $linhasfatura->store($id);
                        break;
                    //case 'show':
                    //    $id = $_GET['id'];
                    //    $linhasfatura->show($id);
                    //    break;
                    //case 'edit':
                    //    $id = $_GET['id'];
                    //    $linhasfatura->edit($id);
                    //    break;
                    //case 'update':
                    //    $id = $_GET['id'];
                    //    $linhasfatura->update($id);
                    //    break;
                    case 'delete':
                        $id = $_GET['id'];
                        $linhasfatura->delete($id);
                        break;
                }
                break;
        }
    }
?>