<h2 class="text-left top-space"Lista de clientes</h2>
<h2 class="top-space"></h2>
<div class="row">
    <div class="col-sm-12">
        <table class="table tablestriped">
            <thead>
                <th class="text-center"><h3>Id</h3></th>
                <th class="text-center"><h3>Username</h3></th>
                <th class="text-center"><h3>Email</h3></th>
                <th class="text-center"><h3>Telefone</h3></th>
                <th class="text-center"><h3>Nif</h3></th>
                <th class="text-center"><h3>Morada</h3></th>
                <th class="text-center"><h3>Codigo postal</h3></th>
                <th class="text-center"><h3>Localidade</h3></th>
                <th class="text-center"><h3></h3></th>
            </thead>
            <tbody>
                <?php foreach ($clientes as $cliente) { ?>
                    <tr>
                        <td class="text-center"><?=$cliente->id?></td>
                        <td class="text-center"><?=$cliente->username?></td>
                        <td class="text-center"><?=$cliente->email?></td>
                        <td class="text-center"><?=$cliente->telefone?></td>
                        <td class="text-center"><?=$cliente->nif?></td>
                        <td class="text-center"><?=$cliente->morada?></td>
                        <td class="text-center"><?=$cliente->codigopostal?></td>
                        <td class="text-center"><?=$cliente->localidade?></td>
                        <td class="text-center">
                            <a href="router.php?c=cliente&a=show&id=<?=$cliente->id ?>"
                            class="btn btn-info" role="button">Show</a>
                            <a href="router.php?c=fatura&a=store&id_cliente=<?=$cliente->id ?>"
                               class="btn btn-info" role="button">Criar fatura</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>