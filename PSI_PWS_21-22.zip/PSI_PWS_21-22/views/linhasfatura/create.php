
<h2 class="text-left top-space">Fatura Create</h2>
<h2 class="top-space"></h2>
<div class="row">
    <div class="col-sm-12">

        <form method="POST" action=<?php echo'./router.php?c=linhasfatura&a=store&id_fatura='. $fatura->id?>
            <br>
            <div class="boxer">
                <div class="row"id="row1">
                    <div class="col-3">
                    <label for="cliente_id">Nome do cliente:</label>
                    <input type="text" name="cliente_id" class="form-control" value="<?= $fatura->user_cliente->username?>" disabled>
                    <br>
                    </div>
                </div>
            </div>

                <div class="card">
                    <div class="card-header">
                        <h4>Produtos</h4>
                    </div>
                    <div class="card-body">
                        <h5>Lista de produtos</h5>
                        <br>
                        <div id="product_form">
                            <div class="row"id="row1">

                                <div class="col">
                                    <label>Referencia do produto</label>
                                    <input type="text" name="referencia" class="form-control">
                                </div>
                                <div class="col-2">
                                    <label>Quantidade</label>
                                    <input type="number" name="quantidade" class="form-control" value="1" min="1">
                                </div>
                            </div>
                        </div>
                        <br>
                        <input type="submit" class="btn btn-dark float-end mt-2" value="adicionar produto">
                        <br><br><br>

                        <?php if($linhasfatura != null){foreach ($linhasfatura as $linhafatura) { ?>
                            <div class="row">
                                <div class="col">
                                    <label>Descrição do produto</label>
                                    <input type="text" class="form-control" value="<?= $linhafatura->produto->descricao ?>" disabled>
                                </div>
                                <div class="col">
                                    <label>Referencia</label>
                                    <input type="number" class="form-control" value="<?= $linhafatura->produto->referencia ?>" disabled>
                                </div>
                                <div class="col">
                                    <label>Valor</label>
                                    <input type="text" class="form-control" value="<?= number_format($linhafatura->valor, 2); ?>€" disabled>
                                </div>
                                <div class="col">
                                    <label>Valor Iva</label>
                                    <input type="text" class="form-control" value="<?= number_format($linhafatura->valoriva, 2);?>€" disabled>
                                </div>
                                <div class="col">
                                    <label>Quantidade</label>
                                    <input type="number" class="form-control" value="<?= $linhafatura->quantidade ?>" disabled>
                                </div>
                                <div class="col">
                                    <p></p>
                                    <?php
                                        echo '<a href="router.php?c=linhasfatura&a=edit&id_linhafatura='. $linhafatura->id .'"
                                            class="btn btn-info" role="button">Editar</a>
                                            <a href="router.php?c=linhasfatura&a=delete&id='. $linhafatura->id .'"
                                            class="btn btn-info" role="button">Apagar</a>';

                                    ?>
                                </div>
                            </div>
                        <?php } }?>
                    </div>
            </div>
            <br>

            <div class="boxer">
                <div class="row end" id="row1">
                    <div class="col-3">
                        <label for="valortotal">Valor total:</label>
                        <input type="text" name="valortotal" class="form-control" value="<?php if(isset($fatura)) { echo number_format($fatura->valortotal,2); }?>€"disabled>
                    </div>

                    <div class="col-3">
                        <label for="ivatotal">Iva total:</label>
                        <input type="text" name="ivatotal" class="form-control" value="<?php if(isset($fatura)) { echo number_format($fatura->ivatotal,2); }?>€" disabled>
                        <br>
                    </div>
                </div>
            </div>

            <br>
        </form>
    </div>
</div>