<br>
    <div>
        <?php
        echo '
            <form action="./router.php?c=auth&a=logout" method="POST">
                <button type="submit">logout</button>
            </form>';
        ?>
    </div>
<br>