
    <?php
        echo '
            <form action="./router.php?c=auth&a=login" method="POST">
                <label for="username">Username:</label><br>
                <input type="text" name="username"><br>
                <label for="password">Password:</label><br>
                <input type="password" name="password"><br><br>
                <input type="submit" value="Submit">
            </form>';
    ?>


